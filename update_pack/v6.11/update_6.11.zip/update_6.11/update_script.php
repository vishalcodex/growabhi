<?php
$CI = get_instance();
$CI->load->database();
$CI->load->dbforge();

//Recaptcha v3 frontend settings 
if($CI->db->get_where('frontend_settings', ['key' => 'recaptcha_status_v3'])->num_rows() == 0){
	$CI->db->insert('frontend_settings', ['key' => 'recaptcha_status_v3', 'value' => '0']);
}
if($CI->db->get_where('frontend_settings', ['key' => 'recaptcha_secretkey_v3'])->num_rows() == 0){
	$CI->db->insert('frontend_settings', ['key' => 'recaptcha_secretkey_v3', 'value' => 'Valid-secret-key-v3']);
}
if($CI->db->get_where('frontend_settings', ['key' => 'recaptcha_sitekey_v3'])->num_rows() == 0){
	$CI->db->insert('frontend_settings', ['key' => 'recaptcha_sitekey_v3', 'value' => 'Valid-site-key-v3']);
}

// update VERSION NUMBER INSIDE SETTINGS TABLE
$settings_data = array('value' => '6.11');
$CI->db->where('key', 'version');
$CI->db->update('settings', $settings_data);