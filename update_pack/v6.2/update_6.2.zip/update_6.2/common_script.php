<?php
$CI = get_instance();
$CI->load->database();
$CI->load->dbforge();
?>
