<?php
$CI = get_instance();
$CI->load->database();
$CI->load->dbforge();


$aamarpay_data['identifier'] = 'aamarpay';
$aamarpay_data['currency'] = 'BDT';
$aamarpay_data['title'] = 'Aamarpay';
$aamarpay_data['keys'] = '{"store_id":"aamarpaytest","signature_key":"dbb74894e82415a2f7ff0ec3a97e4183"}';
$aamarpay_data['model_name'] = 'Payment_model';
$aamarpay_data['enabled_test_mode'] = 0;
$aamarpay_data['status'] = 1;
$aamarpay_data['is_addon'] = 0;
$aamarpay_data['created_at'] = time();
$aamarpay_data['updated_at'] = time();
if($CI->db->where('identifier', 'aamarpay')->get('payment_gateways')->num_rows() >= 1){
    $CI->db->where('identifier', 'aamarpay')->update('payment_gateways', $aamarpay_data);
}else{
    $CI->db->insert('payment_gateways', $aamarpay_data);
}

$flutterwave_data['identifier'] = 'flutterwave';
$flutterwave_data['currency'] = 'NGN';
$flutterwave_data['title'] = 'Flutterwave';
$flutterwave_data['keys'] = '{"public_key":"xxxxxx","secret_key":"xxxxxxxxxx"}';
$flutterwave_data['model_name'] = 'Payment_model';
$flutterwave_data['enabled_test_mode'] = 0;
$flutterwave_data['status'] = 1;
$flutterwave_data['is_addon'] = 0;
$flutterwave_data['created_at'] = time();
$flutterwave_data['updated_at'] = time();
if($CI->db->where('identifier', 'flutterwave')->get('payment_gateways')->num_rows() >= 1){
    $CI->db->where('identifier', 'flutterwave')->update('payment_gateways', $flutterwave_data);
}else{
    $CI->db->insert('payment_gateways', $flutterwave_data);
}

$tazapay_data['identifier'] = 'tazapay';
$tazapay_data['currency'] = 'USD';
$tazapay_data['title'] = 'Tazapay';
$tazapay_data['keys'] = '{"public_key":"xxxxxxxxxx","api_key":"xxxxxxxxx","api_secret":"xxxxxxxxxxx"}';
$tazapay_data['model_name'] = 'Payment_model';
$tazapay_data['enabled_test_mode'] = 0;
$tazapay_data['status'] = 1;
$tazapay_data['is_addon'] = 0;
$tazapay_data['created_at'] = time();
$tazapay_data['updated_at'] = time();
if($CI->db->where('identifier', 'tazapay')->get('payment_gateways')->num_rows() >= 1){
    $CI->db->where('identifier', 'tazapay')->update('payment_gateways', $tazapay_data);
}else{
    $CI->db->insert('payment_gateways', $tazapay_data);
}

$settings_data['key'] = 'iso_country_codes';
$settings_data['value'] = '{"AF":"Afghanistan","AX":"Åland Islands","AL":"Albania","DZ":"Algeria","AS":"American Samoa","AD":"Andorra","AO":"Angola","AI":"Anguilla","AQ":"Antarctica","AG":"Antigua and Barbuda","AR":"Argentina","AM":"Armenia","AW":"Aruba","AU":"Australia","AT":"Austria","AZ":"Azerbaijan","BS":"Bahamas","BH":"Bahrain","BD":"Bangladesh","BB":"Barbados","BY":"Belarus","BE":"Belgium","BZ":"Belize","BJ":"Benin","BM":"Bermuda","BT":"Bhutan","BO":"Bolivia (Plurinational State of)","BQ":"Bonaire, Sint Eustatius and Saba","BA":"Bosnia and Herzegovina","BW":"Botswana","BV":"Bouvet Island","BR":"Brazil","IO":"British Indian Ocean Territory","BN":"Brunei Darussalam","BG":"Bulgaria","BF":"Burkina Faso","BI":"Burundi","CV":"Cabo Verde","KH":"Cambodia","CM":"Cameroon","CA":"Canada","KY":"Cayman Islands","CF":"Central African Republic","TD":"Chad","CL":"Chile","CN":"China","CX":"Christmas Island","CC":"Cocos (Keeling) Islands","CO":"Colombia","KM":"Comoros","CG":"Congo","CD":"Congo (Democratic Republic of the)","CK":"Cook Islands","CR":"Costa Rica","CI":"Côte d&#39;Ivoire","HR":"Croatia","CU":"Cuba","CW":"Curaçao","CY":"Cyprus","CZ":"Czech Republic","DK":"Denmark","DJ":"Djibouti","DM":"Dominica","DO":"Dominican Republic","EC":"Ecuador","EG":"Egypt","SV":"El Salvador","GQ":"Equatorial Guinea","ER":"Eritrea","EE":"Estonia","ET":"Ethiopia","FK":"Falkland Islands (Malvinas)","FO":"Faroe Islands","FJ":"Fiji","FI":"Finland","FR":"France","GF":"French Guiana","PF":"French Polynesia","TF":"French Southern Territories","GA":"Gabon","GM":"Gambia","GE":"Georgia","DE":"Germany","GH":"Ghana","GI":"Gibraltar","GR":"Greece","GL":"Greenland","GD":"Grenada","GP":"Guadeloupe","GU":"Guam","GT":"Guatemala","GG":"Guernsey","GN":"Guinea","GW":"Guinea-Bissau","GY":"Guyana","HT":"Haiti","HM":"Heard Island and McDonald Islands","VA":"Holy See","HN":"Honduras","HK":"Hong Kong","HU":"Hungary","IS":"Iceland","IN":"India","ID":"Indonesia","IR":"Iran (Islamic Republic of)","IQ":"Iraq","IE":"Ireland","IM":"Isle of Man","IL":"Israel","IT":"Italy","JM":"Jamaica","JP":"Japan","JE":"Jersey","JO":"Jordan","KZ":"Kazakhstan","KE":"Kenya","KI":"Kiribati","KP":"Korea (Democratic People&#39;s Republic of)","KR":"Korea (Republic of)","KW":"Kuwait","KG":"Kyrgyzstan","LA":"Lao People&#39;s Democratic Republic","LV":"Latvia","LB":"Lebanon","LS":"Lesotho","LR":"Liberia","LY":"Libya","LI":"Liechtenstein","LT":"Lithuania","LU":"Luxembourg","MO":"Macao","MK":"North Macedonia","MG":"Madagascar","MW":"Malawi","MY":"Malaysia","MV":"Maldives","ML":"Mali","MT":"Malta","MH":"Marshall Islands","MQ":"Martinique","MR":"Mauritania","MU":"Mauritius","YT":"Mayotte","MX":"Mexico","FM":"Micronesia (Federated States of)","MD":"Moldova (Republic of)","MC":"Monaco","MN":"Mongolia","ME":"Montenegro","MS":"Montserrat","MA":"Morocco","MZ":"Mozambique","MM":"Myanmar","NA":"Namibia","NR":"Nauru","NP":"Nepal","NL":"Netherlands","NC":"New Caledonia","NZ":"New Zealand","NI":"Nicaragua","NE":"Niger","NG":"Nigeria","NU":"Niue","NF":"Norfolk Island","MP":"Northern Mariana Islands","NO":"Norway","OM":"Oman","PK":"Pakistan","PW":"Palau","PS":"Palestine, State of","PA":"Panama","PG":"Papua New Guinea","PY":"Paraguay","PE":"Peru","PH":"Philippines","PN":"Pitcairn","PL":"Poland","PT":"Portugal","PR":"Puerto Rico","QA":"Qatar","RE":"Réunion","RO":"Romania","RU":"Russian Federation","RW":"Rwanda","BL":"Saint Barthélemy","SH":"Saint Helena, Ascension and Tristan da Cunha","KN":"Saint Kitts and Nevis","LC":"Saint Lucia","MF":"Saint Martin (French part)","PM":"Saint Pierre and Miquelon","VC":"Saint Vincent and the Grenadines","WS":"Samoa","SM":"San Marino","ST":"Sao Tome and Principe","SA":"Saudi Arabia","SN":"Senegal","RS":"Serbia","SC":"Seychelles","SL":"Sierra Leone","SG":"Singapore","SX":"Sint Maarten (Dutch part)","SK":"Slovakia","SI":"Slovenia","SB":"Solomon Islands","SO":"Somalia","ZA":"South Africa","GS":"South Georgia and the South Sandwich Islands","SS":"South Sudan","ES":"Spain","LK":"Sri Lanka","SD":"Sudan","SR":"Suriname","SJ":"Svalbard and Jan Mayen","SE":"Sweden","CH":"Switzerland","SY":"Syrian Arab Republic","TW":"Taiwan, Province of China","TJ":"Tajikistan","TZ":"Tanzania, United Republic of","TH":"Thailand","TL":"Timor-Leste","TG":"Togo","TK":"Tokelau","TO":"Tonga","TT":"Trinidad and Tobago","TN":"Tunisia","TR":"Turkey","TM":"Turkmenistan","TC":"Turks and Caicos Islands","TV":"Tuvalu","UG":"Uganda","UA":"Ukraine","AE":"United Arab Emirates","GB":"United Kingdom of Great Britain and Northern Ireland","UM":"United States Minor Outlying Islands","US":"United States of America","UY":"Uruguay","UZ":"Uzbekistan","VU":"Vanuatu","VE":"Venezuela (Bolivarian Republic of)","VN":"Viet Nam","VG":"Virgin Islands (British)","VI":"Virgin Islands (U.S.)","WF":"Wallis and Futuna","EH":"Western Sahara","YE":"Yemen","ZM":"Zambia","ZW":"Zimbabwe"}';

if($CI->db->where('key', 'iso_country_codes')->get('settings')->num_rows() >= 1){
    $CI->db->where('key', 'iso_country_codes')->update('settings', $settings_data);
}else{
    $CI->db->insert('settings', $settings_data);
}

// update VERSION NUMBER INSIDE SETTINGS TABLE
$settings_data = array('value' => '6.7');
$CI->db->where('key', 'version');
$CI->db->update('settings', $settings_data);