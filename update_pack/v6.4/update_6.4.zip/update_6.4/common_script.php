<?php
$CI = get_instance();
$CI->load->database();
$CI->load->dbforge();


$CI->db->where('key', 'account_disable');
$row1 = $CI->db->get('settings');

$CI->db->where('key', 'custom_css');
$row2 = $CI->db->get('frontend_settings');

if($row1->num_rows() > 0 && $row2->num_rows() == 0){
	$settings_data1 = array('value' => '6.3');
	$CI->db->where('key', 'version');
	$CI->db->update('settings', $settings_data1);
}
?>
